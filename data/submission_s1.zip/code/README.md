# ZeroSpeech 2019: TTS without T
Our code is provided through a pointer to our public repository (on github):
https://github.com/andi611/ZeroSpeech-TTS-without-T